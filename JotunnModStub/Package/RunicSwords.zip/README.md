# Runic Swords

This is a mod that adds various empowered swords to the game following the viking style they are embewed with runes to hold their power. 

Will update more here next time I feel creative 


Thnks Jotunn for the heavy lifting I just made some assets ;)


**V0.0.1**
Initial Alpha Release

These swords were meant for more "hard" servers yes the crafting reqs are alot yes they are OP no I wont turn them down 

TLDR 
Have fun destroying things with god weapons
