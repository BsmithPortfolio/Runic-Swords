# Runic Swords

This is a mod that adds various empowered swords to the game following the viking style they are embewed with runes to hold their power. 

Will update more here next time I feel creative 


Thnks Jotunn for the heavy lifting I just made some assets ;)


**V0.0.1**
Initial Alpha Release

**V0.0.2**

Changed from artisan table to forge cuz for some reason it doesn't show up at artisan table?

**V0.0.3**

Changed back to artisan table and added build table extension pieces to allow you to actually level your weapon ;) 

**V0.0.4**
idk i missed a ver

**V0.0.5***
Fixed the piece placement of runic upgrades for crafting table

**V0.0.6***
Fully configurable and added some shiny light things to the swords

These swords were meant for more "hard" servers yes the crafting reqs are alot yes they are OP no I wont turn them down 

TLDR 
Have fun destroying things with god weapons
